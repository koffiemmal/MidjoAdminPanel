import React, { useEffect, useState } from 'react'
import style from '../styles/UserList.module.css'
import { collection, getDocs } from 'firebase/firestore'
import { db } from '../../api/firebaseConfig'
import {CloseIcon} from '@chakra-ui/icons'
const StationList = () => {

    const [station,setStation] = useState([])

    useEffect(()=>{
        const fetchData = async ()=>{

            try{
                const querySnapchot = await getDocs(collection(db,"station"));

                const stationData = querySnapchot.docs.map((doc)=>({
                    id:doc.id,
                ...doc.data()                }))
                setStation(stationData);
                console.log(stationData);
            }
            catch{

            }

        };
        fetchData();
    },[])


  return (



    <div className={style.mainUser}>
      <div>
        <section className={style.place}>
          <h4>Point de stationnement</h4>
        </section>
      </div>

      <div className={style.container}>
        <table className={style.table}>
          <thead>
            <tr>
              <th>Id</th>
              <th>Nom</th>
              <th>latitude</th>
              <th>longitude</th>
              <th>positionTime</th>
              <th>supression</th>
            </tr>
          </thead>
          <tbody>
           {station.map((stations) => (
              <tr key ={stations.id}>
                <td>{stations.id}</td>
                <td>{stations.nom}</td>
                <td>{stations.latitude}</td>
                <td>{stations.longitude}</td>
                <td>{stations.time}</td>
                <td> <button> <CloseIcon/> </button> </td>
              </tr>
            ))} 
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default StationList
