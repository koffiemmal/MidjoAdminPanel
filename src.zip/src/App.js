import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Header from './components/layouts/Header';
import Userlist from './components/pages/Userlist';
import StationList from './components/pages/StationList';
import AddStationList from './components/pages/AddStationList';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Header />}>
          <Route index element={<Userlist />} />
          <Route path="/station"  element={<StationList/>}/>
          <Route   path='/addStation' element={<AddStationList/>} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
